<?php 
class ThemeOptions_ExtraConfig_Helper_Data extends Mage_Core_Helper_Abstract
{
	/*
	public function getCustomCssName() {
		if (Mage::getStoreConfig('mygeneral/generaloptions/use_custom_css', Mage::app()->getStore()->getId()) == 1) 
			return Mage::getStoreConfig('mygeneral/generaloptions/custom_css_name', Mage::app()->getStore()->getId());
		else
			return "";
	}
	*/ 
}