<?php
class Mage_Catalog_Block_Product_Listmedia extends Mage_Core_Block_Template
{
    public function getTest()
    {
        return 'asd';
    }
}
