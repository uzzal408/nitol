<?php
class Vivacity_Flikebox_Model_Layout
{
 
     public function toOptionArray()
         {
			$option  = array(
			"left"=>'Left Column',			
			"right"=>'Right Column');
			return $option;  
	     }

}
?>

